package ae.etisalat.bscs;

import com.expressui.core.MainApplication;
import com.expressui.core.view.menu.MenuBarNode;

/**
 * Main application class.
 */
public class BscsApplication extends MainApplication {

	@Override
	public void configureLeftMenuBar(MenuBarNode arg0) {
		// TODO Auto-generated method stub
		System.out.println("Rakesh");
	}

	@Override
	public void configureRightMenuBar(MenuBarNode arg0) {
		// TODO Auto-generated method stub
		System.out.println("Rakesh");
		
	}

	

}

